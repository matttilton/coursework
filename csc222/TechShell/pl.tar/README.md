Matthew Tilton
2017-02-17
TechShell
Most things work but I could not get redirection to function correctly.
Simple commands should work.
Built in commands work (cd, pwd, exit).
Shell does correctly show errors from wherever I could think to catch them.